//
//  MyButtone.swift
//  whitherEYAS
//
//  Created by eyas seyam on 4/13/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit
@IBDesignable
class MyButtone: UIButton {
    
    @IBInspectable var BorderWhith : CGFloat = 0 {
        didSet {
            self.layer.borderWidth = BorderWhith
        }
    }
    
    
    @IBInspectable var BorderColor : UIColor = UIColor.clear {
        didSet {
            self.layer.borderColor = BorderColor.cgColor
        }
    }
    
    
    @IBInspectable var CornarRaduis : CGFloat = 0 {
        didSet {
            self.layer.cornerRadius = CornarRaduis
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.clipsToBounds = true
        
    }

  

}
