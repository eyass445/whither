//
//  ViewController.swift
//  whitherEYAS
//
//  Created by eyas seyam on 4/13/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit

class ViewController: UIViewController  , WhiterServisDelegate {
    
    
    
    func WhitherErorrWiteMassege(massege: String) {
        let alert = UIAlertController(title: "Erorr", message: massege, preferredStyle: .alert )
        let OK = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(OK)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    func SetWhither(whither: Whither) {
        // ll : لتحويل رقم الضبل الى خانات ديسمل حسب الحاجة
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 0
        let f = formatter.string(from: NSNumber(value: whither.tempC))
        
        //print("cityName : \(whither.cityName) , temp : \(whither.temp) , des : \(whither.des) ")
        TempLable.text = "\(f!)"
        WhitcImag.image = UIImage(named: "\(whither.icon)")
        HumidityLable.text = "\(whither.humidity)"
        WhindLable.text = "\(whither.wind)"
        city.text = "\(whither.cityName)"
        
    }
    
    
    
    
    
    
    @IBOutlet weak var city: UILabel!
    
    @IBOutlet weak var WhitcImag: UIImageView!
    @IBOutlet weak var TempLable: UILabel!
    @IBOutlet weak var HumidityLable: UILabel!
    @IBOutlet weak var WhindLable: UILabel!
   // var Whithersirv = WhiterServis()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        WhitcImag.layer.cornerRadius = 20
        WhitcImag.clipsToBounds = true
        WhiterServis.delegate = self
        
    }
    
    
    @IBAction func GetCity(_ sender: Any) {
        CreatAlertCont()
        
    }
    
    // : -  UIAlertController
    @objc func CreatAlertCont () {
        let alert = UIAlertController(title: "City", message: "Enter your City", preferredStyle: .alert)
        let canelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(canelAction)
        
        let OkAction = UIAlertAction(title: "OK", style: .default) { (action : UIAlertAction) in
            let textF = alert.textFields![0]
            let city = textF.text!
            WhiterServis.GetWhither(city: city)
        }
        alert.addTextField { (textFild:UITextField ) in
            textFild.placeholder = "City Name "
        }
        alert.addAction(OkAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    
    
}


