//
//  WhiterServis.swift
//  whitherEYAS
//
//  Created by eyas seyam on 4/13/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import Foundation

// لتسريع عملية الطلب ولتحميل المعلومات 
protocol WhiterServisDelegate {
    func SetWhither (whither : Whither)
    func WhitherErorrWiteMassege (massege : String)
}

class WhiterServis {
    
    static var delegate : WhiterServisDelegate?
    
    
    
    static func GetWhither (city : String) {
        
        // rspons erorr
        // cod :-  = 401 :::-  يعني خطأ في api
        // cod :-  = 404 :::-  المنطقة غير موجودة
        
        // reqwist طلب معلومات من الرابط ال يو ار ال
        let appid = "4ba6c468386f8ac2385a4c1dcd5b2af9"
        let path = "https://api.openweathermap.org/data/2.5/weather?q=\(city)&appid=\(appid)"
        let url = URL(string: path)
        let request = URLRequest(url: url!)
        let task = URLSession.shared.dataTask(with: request) { (data, respons, error) in
            
//            if let httprespons = respons as? HTTPURLResponse {
//
//                print("************")
//                print(httprespons.statusCode)
//                print("************")
//
//
//            }
//            
            do {
                if error == nil {
                    if let UNRappedData = data {
                        
                        
                        let json = try JSON(data: UNRappedData)
                        
                        var status = 0
                        if   let cod = json["cod"].int {
                            
                            status = cod
                        
                        } else if let cod2 = json["cod"].string {
                            status = Int(cod2)!
                            
                        }
                        
                        
                        
                        if status == 200 {
                            
                            
                            let Lon = json["coord"]["lon"].double
                            let Lat = json["coord"]["lat"].double
                            let temp = json["main"]["temp"].double
                            let Name = json["name"].string
                            let state = json["weather"]["main"].string

                            let des = json["weather"][0]["description"].string
                            let icon = json["weather"][0]["icon"].string
                            let hum = json["main"]["humidity"].double
                            let wind = json["wind"]["speed"].double
                            
                            
                            let weatherJS = Whither(cityName: Name!, temp: temp!, des: des!, icon: icon!, humidity: hum!, wind: wind!)
                            
                            if delegate != nil{
                                DispatchQueue.main.async {
                                    self.delegate?.SetWhither(whither: weatherJS)
                                    
                                }
                                
                            }
                            
                            /* print("lat : \(Lat) , lon : \(Lon) , temp : \(temp) , des : \(des)") */

                            
                        } else if status == 404 {
                            
                            if self.delegate != nil {
                                DispatchQueue.main.async {
                                    self.delegate?.WhitherErorrWiteMassege(massege: "City Not Found")
                            }
                          }
                        } else {
                            if self.delegate != nil {
                                DispatchQueue.main.async {
                                    self.delegate?.WhitherErorrWiteMassege(massege: "something Wrong")
                             }
                          }
                        }
                        
                    }
                }
                
            } catch{
                print("erorr")
            }
        } .resume()
        
        
        
        // jeson استخدام الجيسون في التطبيق
        //            do {
        //                if error == nil {
        //
        //                    if let UNRappedData = data {
        //
        //                        let json = try JSON(data: UNRappedData)
        //                        let Lon = json["coord"]["lon"].double
        //                        let Lat = json["coord"]["lat"].double
        //                        let temp = json["main"]["temp"].double
        //
        //                        print("lat : \(Lat) , lon : \(Lon) , temp : \(temp)")
        //
        //                    }
        //                }
        //            }
        
        
        
        /*
        let whither = Whither(cityName: city , temp: 232.4, des: "i heat the sety")
        print("eyas need live \(city)")
        if delegate != nil {
        self.delegate?.SetWhither(whither: whither)
        }
        */
        //
        // b6907d289e10d714a6e88b30761fae22
    }
}
