//
//  File.swift
//  whitherEYAS
//
//  Created by eyas seyam on 4/14/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import Foundation

    struct Whither {
        
        let cityName : String
        let temp : Double
        let des : String
        let icon : String
        let humidity : Double
        let wind : Double
        
        
        var tempC : Double {
            get {
                return temp - 273.15
            }
        }

        init(cityName : String , temp : Double , des : String , icon : String , humidity : Double , wind : Double ) {
            self.cityName = cityName
            self.temp = temp
            self.des = des
            self.icon = icon
            self.humidity = humidity
            self.wind = wind
            
        }
            
            
            
        
        
        
    }
    
    

